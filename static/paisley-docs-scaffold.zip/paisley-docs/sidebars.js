module.exports = {
  overviewSidebar: [
    'overview/index'
  ],
  timeTokensSidebar: [
    'time-tokens/intro',
    'time-tokens/how-to-sell'
  ],
  walletSidebar: [
    'wallet/intro'
  ],
  coopSidebar: [
    'coop/what-is-a-coop'
  ]
};
