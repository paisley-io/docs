---
id: how-to-sell
title: How to Sell
sidebar_label: Sell Tokens
sidebar: timeTokensSidebar
---

Instructions for creating and selling Time Tokens.
