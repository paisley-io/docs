---
id: intro
title: Time Tokens
sidebar_label: Intro
sidebar: timeTokensSidebar
---

Learn what Time Tokens are and how to use them.
