---
id: what-is-a-coop
title: What is a Coop?
sidebar_label: What is a Coop?
sidebar: coopSidebar
---

Understanding cooperatives and how Paisley is structured.
