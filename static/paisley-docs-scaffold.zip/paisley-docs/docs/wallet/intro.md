---
id: intro
title: Wallet Overview
sidebar_label: Intro
sidebar: walletSidebar
---

Everything you need to know about the Paisley wallet.
