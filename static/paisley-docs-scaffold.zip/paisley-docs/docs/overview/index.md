---
id: index
title: Welcome to Paisley
sidebar_label: Intro
sidebar: overviewSidebar
---

Welcome to Paisley! Here's what we're about...
